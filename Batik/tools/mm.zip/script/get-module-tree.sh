#!/sbin/sh

module=$1

workPath=/magisk

/tmp/mmr/script/tree ${workPath}/${module}
